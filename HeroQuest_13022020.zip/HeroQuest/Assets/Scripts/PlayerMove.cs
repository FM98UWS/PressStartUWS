﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public Camera cam; //defines camera

    private Rigidbody2D rb; //defines rigidbody2d

    private Animator anim;
    public float animfactor;
    private bool moving = false;

    private bool movingUP = false;
    private bool movingDOWN = false;
    private bool movingLEFT = false;
    private bool movingRIGHT = false;




    //public string horizontalinput = "Horizontal"; //gets horizontal input
    //public string verticalinput = "Vertical"; //gets vertical input
    private float haxis;
    private float vaxis;

    public float power;
    public float speed = 10f;
    public float maxSpeed = 5;

    public float lookAtTheSpeedX; //used to see speed in x-axis
    public float lookAtTheSpeedY; //used to see speed in y-axis

    public float lookAtH; //used to see speed in x-axis
    public float lookAtV; //used to see speed in y-axis


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>(); //gets rigidbody2d from attached GameObject
        anim = GetComponent<Animator>();

    }

    // Update is called once per frame
    void Update()
    {
        haxis = Input.GetAxis("Horizontal");
        vaxis = Input.GetAxis("Vertical");

        anim.SetFloat("HSpeed", (Mathf.Abs(Input.GetAxis("Horizontal"))));
        anim.SetFloat("VSpeed", (Mathf.Abs(Input.GetAxis("Vertical"))));
        anim.SetBool("Moving", moving);
        anim.SetBool("MovingUp", movingUP);
        anim.SetBool("MovingDown", movingDOWN);
        anim.SetBool("MovingLeft", movingLEFT);
        anim.SetBool("MovingRight", movingRIGHT);


        //if (Input.GetButtonDown("Right"))
        //{
        //    rb.AddForce(Vector2.right * speed, ForceMode2D.Impulse);
        //}

        //if (Input.GetButtonDown("Left"))
        //{
        //    rb.AddForce(Vector2.right * -speed, ForceMode2D.Impulse);
        //}
    }

    float timer;
    private void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        rb.AddForce(Vector2.right * speed * h, ForceMode2D.Impulse);
        rb.AddForce(Vector2.up * speed * v, ForceMode2D.Impulse);

        lookAtTheSpeedX = rb.velocity.x; //for checking speed in the x-axis
        lookAtTheSpeedY = rb.velocity.y; //for checking speed in the y-axis

        lookAtH = h; //for checking speed in the x-axis
        lookAtV = v; //for checking speed in the y-axis

        if ((h > 0 && v > 0) || (h < 0 && v < 0) || (h > 0 && v < 0) || (h < 0 && v > 0))
        {
            rb.velocity = new Vector2 (0,0);
        } //hopefully locks movement if more than two directions are input at once


        //if (h == 0 && v == 0)
        //{
        //    timer += Time.deltaTime;
        //    if (timer > 0.1f)
        //        moving = false;
        //}
        //else
        //{
        //    timer = 0;
        //    moving = true;
        //}

        //if (rb.velocity.y > 2)
        //{
        //    movingUP = true;
        //}
        //else if (rb.velocity.y >= 0 && rb.velocity.y < 2)
        //{
        //    movingUP = false;
        //}
        //if (rb.velocity.y < -2)
        //{
        //    movingDOWN = true;
        //}
        //else if (rb.velocity.y > -2 && rb.velocity.y < 0)
        //{
        //    movingDOWN = false;
        //}

        //if (rb.velocity.y > 0)
        //{
        //    movingUP = true;
        //}

        //if (rb.velocity.y < 0)
        //{
        //    movingDOWN = true;
        //}

        //if (this.anim.GetCurrentAnimatorStateInfo(0).IsName("HeroWalkBack") && v == 0)
        //{
        //    movingUP = false;
        //    rb.velocity = new Vector2 (0,0);
        //    v = 0;
        //}
        //if (this.anim.GetCurrentAnimatorStateInfo(0).IsName("HeroWalkDOWN_test") && v == 0)
        //{
        //    movingDOWN = false;
        //    rb.velocity = new Vector2(0, 0);
        //    v = 0;
        //}

        //caps Player speed in positive X
        if (rb.velocity.x > maxSpeed)
        {
            rb.velocity = new Vector2(maxSpeed, rb.velocity.y);
        }

        //caps Player speed in negative X
        if (rb.velocity.x < -maxSpeed)
        {
            rb.velocity = new Vector2(-maxSpeed, rb.velocity.y);
        }

        //caps Player speed in positive Y
        if (rb.velocity.y > maxSpeed)
        {
            rb.velocity = new Vector2(rb.velocity.x , maxSpeed);
        }

        //caps Player speed in negative Y
        if (rb.velocity.y < -maxSpeed)
        {
            rb.velocity = new Vector2(rb.velocity.x, -maxSpeed);
        }
    }

}
