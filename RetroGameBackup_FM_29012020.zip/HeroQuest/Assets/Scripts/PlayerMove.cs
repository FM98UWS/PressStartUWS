﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public Camera cam; //defines camera

    private Rigidbody2D rb; //defines rigidbody2d

    private Animator anim;
    public float animfactor;
    private bool moving = false;

    //public string horizontalinput = "Horizontal"; //gets horizontal input
    //public string verticalinput = "Vertical"; //gets vertical input
    private float haxis;
    private float vaxis;

    public float power;
    public float speed = 10f;
    public float maxSpeed = 3;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>(); //gets rigidbody2d from attached GameObject
        anim = GetComponent<Animator>();

    }

    // Update is called once per frame
    void Update()
    {
        haxis = Input.GetAxis("Horizontal");
        vaxis = Input.GetAxis("Vertical");

        anim.SetFloat("HSpeed", (Mathf.Abs(Input.GetAxis("Horizontal"))));
        anim.SetFloat("VSpeed", (Mathf.Abs(Input.GetAxis("Vertical"))));
        anim.SetBool("Moving", moving);

        //if (Input.GetButtonDown("Right"))
        //{
        //    rb.AddForce(Vector2.right * speed, ForceMode2D.Impulse);
        //}

        //if (Input.GetButtonDown("Left"))
        //{
        //    rb.AddForce(Vector2.right * -speed, ForceMode2D.Impulse);
        //}
    }

    float timer;
    private void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        rb.AddForce(Vector2.right * speed * h, ForceMode2D.Impulse);
        rb.AddForce(Vector2.up * speed * v, ForceMode2D.Impulse);

        if ((h > 0 && v > 0) || (h < 0 && v < 0) || (h > 0 && v < 0) || (h < 0 && v > 0))
        {
            rb.velocity = new Vector2 (0,0);
        } //hopefully locks movement if more than two directions are input at once


        if (h == 0 && v == 0)
        {
            timer += Time.deltaTime;
            if (timer > 0.1f)
                moving = false;
        }
        else
        {
            timer = 0;
            moving = true;
        }
    }

}
