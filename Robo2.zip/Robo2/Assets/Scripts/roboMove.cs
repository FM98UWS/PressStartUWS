﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class roboMove : MonoBehaviour
{
    //jumping
    public float power;
    public float speed = 50f;
    public float maxSpeed = 3;
    //jumping
    public float jumppower = 1;
    public float jumpnum = 1;
    private bool jumping = false;
    private bool onsomething = true;

    private float haxis;
    private float vaxis;
    private Rigidbody2D rb;
    private Animator anim;

    public float animfactor;

    public string horizontalinput = "Horizontal";
    public string verticalinput = "Vertical";

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    //private void OnCollisionEnter2D(Collision2D collision)
    //{
    //    if (transform.position.y > collision.transform.position.y) //only allows the Player to jump on top of platforms
    //    {
    //        onsomething = true; // Check for the player colliding with anything and  set the boolean to true if it does
    //        jumpnum = 1; //allows the Player to jump again
    //    }
    //}

    void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("Entered");
        if (collision.gameObject.CompareTag("ground"))
        {
            onsomething = true;
            jumpnum = 1;
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        Debug.Log("Exited");
        if (collision.gameObject.CompareTag("ground"))
        {
            onsomething = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        haxis = Input.GetAxis("Horizontal");
        vaxis = Input.GetAxis("Vertical");

        if (Input.GetButtonDown("Jump") && (onsomething == true) && (jumpnum >0))
        {
            rb.AddForce(transform.up * jumppower, ForceMode2D.Impulse);
            //jumpnum -= 1;
        }
    }

    private void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal");
        rb.AddForce(Vector2.right * speed * h, ForceMode2D.Impulse);


        //caps Player speed
        if (rb.velocity.x > maxSpeed)
        {
            rb.velocity = new Vector2(maxSpeed, rb.velocity.y);
        }

        //caps Player speed
        if (rb.velocity.x < -maxSpeed)
        {
            rb.velocity = new Vector2(-maxSpeed, rb.velocity.y);
        }
    }
}
